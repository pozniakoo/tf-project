import boto3

def lambda_handler(event, context):
    ec2_client = boto3.client('ec2')

    response = ec2_client.describe_instances(
        Filters=[
            {
                'Name': 'instance-state-name',
                'Values': ['running']
            }
        ]
    )

    instance_ids = [instance['InstanceId'] for reservation in response['Reservations'] for instance in reservation['Instances']]

    if instance_ids:
        ec2_client.stop_instances(InstanceIds=instance_ids)
        print(f"Stopped:: {', '.join(instance_ids)}")
    else:
        print("No instances to stop")